# The structure for xm l result from cerine website

## MetaData:
* author: \<contrib contrib-type="author">
* title: <article-title> Kauri: Scalable BFT Consensus With Pipline
* paragraph: \<sec id = "sec-1">
